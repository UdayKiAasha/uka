<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
</head>

<body>
<?php 
	$auth = "Y0iWcR9j810wfn12euT6LIE289jGoYyIULDQesdlKu";
	//$i_s_id_1 = urldecode("DyPo75u9ZjBVflrenSYetF6UHLRhzT4cpGLNgqDfT%2FwpIkEEbxcsR8S3oyHCnwujO384SQviNA2Ud%2BnyEE7BmNdIALyqicDUS0fDuXdu%2BvoCj%2B%2BLXbi2G7HM3I%2FjrB7jVYET2t5yteDJ9nSDGH3np3aT7MVFYuxACMegG3iBHKStDhldAN4Iwd5K4s5ERbKtkuB6jQyDm4rgzy04YFAqgsvwkukgtJ4V%2BEOIoe7l49uEdDSFZwkessNsjfAGp9Ha1O9rtrJbSLlDOtzXObR3%2FQkW9sW03vOkoQSFise36Ug1AysjU%2Fi2EMuixQ0UIJ%2FFPuvZ0MZ3uQN%2FwQCXTqNA9etXSLdjSnIkP8xV0jS4nsRu9Qe5COMaTY217Hg6xAm2obG0zYpDgXPcZOyOIE6LJTRyBddJQfzl9cJCCKTOhzzOyTJf4PuzrUU4rCh1mZH5dUqFKoAsJdtongRzok2E1LuzDO0wVbIa3p7X0JQvjDV0StkdPTCXCpAJTwwTQaA6v%2FVd%2Bosi0uWyPadvmna9lGLFXn4ePcL0W1YY53b7fChCfKOy0F%2FP5eTVBQSukdbcgDDy03jv6HgvnfW1urkXHwcLQm3AEntyOJIWvlF%2B2Ni8tgXyZQ74bBI7lxn429S9G6yq20PWaWWHSgL%2BrW%2B9TggL42VvxTO1xs2JDCgb9rhBKcp72651mAf33WP7RkXrkFiXllim1DxIHCRizaK%2B26v6jQqDrVUbQydYHSzFIGMGCcqUz9USIPTnW%2BiguW%2BzPYlsKliK3%2Fggr%2BQMDEts5pn5dYZpV0gC%2BgIX1zpMAg89WAtVqje9MC5g0OJHNSYUcHx8rHrvaodBA5aqfgp7inJAdB2lsW96OT%2BitnJBqxtmzICsc8NEJ%2FEkVmyEoF1WSiYYD3BIMmfBjsHtnD4pb%2BVDu6RXnJL6iGdv2q0C8cMh2R%2FFhe%2FTVTT1qZ43B0iR%2BPX4TyKlpnx%2BjJpKNr382Y8qNTW3TtbHJ1si9WS5lUM%3D");
	//$i_s_id_2 = urldecode("xEyVpXnL6uahyuecZwGBbtdweo6kTqPCfhBEQU81WdB9WWHjPNnQ%2BnZ0YzNqUWxFIbZ8HgRe7yUlYNue3Ra5W2cbXoGH4AGhRukOioHYnaZpiYA%2Bo0Gqx77OCaaslbhoiu%2FH1YCymsrANoCPYooalHeKYKlJVUhXX420Jr0CjwV4rIOzOm%2BhwwOd7D0A9U1MPCkET%2ByP4tLOQ80MSp4CSJX1pykm85nChqCKiD8vdLqAsS8%2FyTyBKqWUBte%2F%2FXYKtqXwKNEckPK6jJ5iJC6FD1gMq%2FfhRRTJ5tzDRz7WnfxY57WOegQZM6FGZ7JSRcgUVJ3butuBmJ6P0gJDXjeRDNZOUZ%2Bx5Ifq5CysBuDENUWoNX%2F%2BrHXAmUL9BdHuqVPOqzjUd%2BiYhASTc7olAU39OPnsv5%2Ben6GgW%2F%2Fhw%2FxyojD6VEV2GW7F%2FB49BZ8wGFM5u8DN8pN1%2FzqYvElTG%2FKmnh9myeim5B2FSglkwJjKoOYwZP%2BT%2F5fNtrr%2BwRZXQCgw904t7VRECwQ4dBSgjes0pD8O1wWZyGvUyH7RmkjuJCZRMI%2F9J2wQuu6599KbGR1xElogBoc4sdh%2FHMoD5VpSHiqHkeHp0OkUF9glomVjvt5tZ1M9jOecmeu3tyRPZcDZVV1wlJKDR%2Bs3LVA5cpPqeSgSRXF0SChy%2FpxvI2vOrECxFcOI7eLDWssokzY%2BjDEJJhvaHZJUS4eKe%2BBT0fUxlygxykMK%2FN8DT1t5FyLtt9vBHrqJE1KVjb2%2FevmGmnWobSs%2BGxj%2B97JbfkHOpyidmkg8lkNEoiAsOmXwFn23V4n3T3WpVbLti6CGm%2FNj1M%2FlQBlld%2FRZjPA0TnmU9M4H0zXbGTpKd9RXLCFaVZFIX3IJS51%2BL4HYB1doIxNjV7%2BqvCCMa2wF0ZMuG%2B80OL0ATLj6Xudm7mKtztYaN1ePTpllSq9fNnJERNcOciEUILuupqa8DMlktmoVdXGjrUO4zhF2lr4yCwfQAGYY72YDTWM%3D");
	
	//$auth = $_POST["auth"];
	
	$i_s_id_1 = urldecode($_GET['i_s_id_1']);
	
	$i_s_id_2 = urldecode($_GET["i_s_id_2"]);
?>
<script type="text/javascript" >

 var i_s_id_1 = decodeURIComponent("<?php echo $i_s_id_1; ?>");
 var i_s_id_2 = decodeURIComponent("<?php echo $i_s_id_2; ?>");
  
  var params = {
    'host': "iris-cloud.com:8188/uniqbio/irisserver", 
    'signature1': i_s_id_1,
    'signature2': i_s_id_2,
    'param1': '' }; // parameters

  // service endpoint
  var url = 'https://' + params.host + '/compare?access_token=<?php echo $auth; ?>' ;
  var payload = '{ "iris_signature1": "' + params.signature1
        + '", "iris_signature2": "' + params.signature2 + '" }';
  
  // construct payload
  var xmlhttp = new XMLHttpRequest();

  xmlhttp.open('POST', url, true);
  // add required headers
  xmlhttp.setRequestHeader('Content-Type', 'application/json');
  xmlhttp.setRequestHeader('Accept', 'application/json');
  
  xmlhttp.send(payload);
  xmlhttp.onreadystatechange = function() {
    if (xmlhttp.readyState == 4) {
      if ( xmlhttp.status == 200) {
        var json_response = JSON.parse(xmlhttp.responseText);
        compare_result = JSON.stringify(json_response);  
		//if(compare_result.status == "MATCH") {
        	$('#result').html(compare_result);
		//}
      }
      else {
        $('#iris_compare').text("ERROR - " + xmlhttp.responseText);
      }
    }
  }
</script>

<p id="result"></p>
</body>
</html>
