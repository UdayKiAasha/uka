<?php
  // Define database connection constants
  define('DB_HOST', 'localhost');
  define('DB_USER', 'hmroot');
  define('DB_PASSWORD', 'rua80046');
  define('DB_NAME', 'helpme');
?>











